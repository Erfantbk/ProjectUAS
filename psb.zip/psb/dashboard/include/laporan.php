<h2>Laporan</h2>


<div class="row">
    <div class="col-sm-12 col-md-8 col-lg-10 col-lg-offset-1">
        <div class="card" style="margin-top: 50px">
            <div class="card-header" data-background-color="blue">
                <h4 class="title"><i class="fa fa-print"></i> Laporan</h4>
                <p class="category"></p>
            </div>
            <div class="card-content" style="align-items: center;">
            
		

			<div class="row">
				<center><a href="include/cetak_laporan_pendaftar.php" class="btn btn-primary"><i class="fa fa-print"></i> Cetak Laporan Pendaftar</a></center>
			</div>

			<div class="row">
				<center><a href="include/cetak_laporan_pendapatan.php" class="btn btn-primary"><i class="fa fa-print"></i> Cetak Laporan Pendapatan</a></center>
			</div>

			<div class="row">
				<center><a href="include/cetak_laporan_kegiatan.php" class="btn btn-primary"><i class="fa fa-print"></i> Cetak Laporan Kegiatan</a></center>
			</div>
			
          
            </div>
        </div>
    </div>
</div>



